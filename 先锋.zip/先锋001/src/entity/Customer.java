package entity;

import java.util.Date;

public class Customer {
	private int id;
	//�ͻ����
	private String customerNo;
	//�ͻ�����
	private String customerName;
	//�ͻ��Ա�
	private String customerSex;
	//�ͻ�����
	private int age;
	//�ͻ�����֤
	private String customerPcard;
	//�ͻ��绰
	private String customerTel;
	//�ͻ�������
	private Date customerBoth;
	//�ͻ�סַ
	private String customerAddress;
	//�ͻ�������
	private String customerRoomID;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerSex() {
		return customerSex;
	}
	public void setCustomerSex(String customerSex) {
		this.customerSex = customerSex;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getCustomerPcard() {
		return customerPcard;
	}
	public void setCustomerPcard(String customerPcard) {
		this.customerPcard = customerPcard;
	}
	public String getCustomerTel() {
		return customerTel;
	}
	public void setCustomerTel(String customerTel) {
		this.customerTel = customerTel;
	}
	public Date getCustomerBoth() {
		return customerBoth;
	}
	public void setCustomerBoth(Date customerBoth) {
		this.customerBoth = customerBoth;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public String getCustomerRoomID() {
		return customerRoomID;
	}
	public void setCustomerRoomID(String customerRoomID) {
		this.customerRoomID = customerRoomID;
	}
	
	
		
	
}
