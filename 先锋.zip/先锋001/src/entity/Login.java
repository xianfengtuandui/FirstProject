package entity;

public class Login {
	private int id;
	//��½�˺�
	private String LoginNo;
	//��½����
	private String LoginPw;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLoginNo() {
		return LoginNo;
	}
	public void setLoginNo(String loginNo) {
		LoginNo = loginNo;
	}
	public String getLoginPw() {
		return LoginPw;
	}
	public void setLoginPw(String loginPw) {
		LoginPw = loginPw;
	}
	

}
