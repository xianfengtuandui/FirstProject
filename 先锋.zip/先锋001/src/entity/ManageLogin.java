package entity;

public class ManageLogin {
	private int id;
	//��½���
	private String LNo;
	//��½����
	private String LPw;
	//����
	private String LNA;
	public String getLNA() {
		return LNA;
	}
	public void setLNA(String lNA) {
		LNA = lNA;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getLNo() {
		return LNo;
	}
	public void setLNo(String lNo) {
		LNo = lNo;
	}
	public String getLPw() {
		return LPw;
	}
	public void setLPw(String lPw) {
		LPw = lPw;
	}
	

}
